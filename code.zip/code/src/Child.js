import React from 'react'
import PropTypes from "prop-types";
import {updateEmpActionCreator} from "./actions/actionCreator"
import {connect} from "react-redux";

function mapDispatchToProps(dispatch)
{
    return ({
        onSaveStore:(editedEmp)=>{return dispatch(updateEmpActionCreator(editedEmp))}
    })
}

class Child extends React.Component {
    constructor(props) {
        super(props);
        this.empNameRef = React.createRef();
        this.salaryRef = React.createRef();
    }
    saveDetailsEventHandler = () => {
        var updatedObj = {
            empId: this.props.editableEmployee.empId,
            empName: this.empNameRef.current.value,
            salary: this.salaryRef.current.value
        }
        console.log("Updated Employee Details", updatedObj);
        this.props.onConfirmSave();// trigger the event
        this.props.onSaveStore(updatedObj);

    }
    render() {
        console.log("Data from the Parent", this.props);
        console.log("Employee Data from the Parent", this.props.editableEmployee);
        var empDetails = { ...this.props.editableEmployee };
        return (
            <React.Fragment>
                <h1>Child Component</h1>
                <form>
                    <div>
                        <label>Employee Id</label>
                        <label>{empDetails.empId}</label>
                    </div>
                    <div>
                        <label>Employee Name</label>
                        <input type="text" ref={this.empNameRef} defaultValue={empDetails.empName} />
                    </div>
                    <div>
                        <label>Salary</label>
                        <input type="text" ref={this.salaryRef} defaultValue={empDetails.salary} />
                    </div>
                    <div>

                        <input type="button" value="Save Details" onClick={this.saveDetailsEventHandler} />
                    </div>
                </form>
            </React.Fragment>
        )
    }


}
Child.propTypes = {
    editableEmployee: PropTypes.object,
    data: PropTypes.object.isRequired,
    age: (props, propName) => {
        if (typeof props[propName] == "number") {
            if (props[propName] < 18)
                return new Error("Age should be greater than 18")
            else
                return null;
        }
        else
            return new Error("Age should be a number");
    }
}

Child.defaultProps={
    data:100
}
export default connect(null,mapDispatchToProps)(Child);