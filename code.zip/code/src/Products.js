import React from 'react'
import AddToCart from './AddToCart';

class Products extends React.Component
{
    constructor(props) {
        super(props);
        this.state = {
            showAddToCart: false,
            selectedProduct: {},
            productsArr: this.props.productsArr
        };
    }
    addCartEventHandler = (obj) => {
        this.setState({ showAddToCart: true, selectedProduct: obj });
    }
    onCancelConfirmEventHandler = () => {
        this.setState({ showAddToCart: false });
    }
    onConfirmSelectionEventHandler = (cartObj) => {
        console.log("Cart Obj in Products", cartObj);
        this.setState({ showAddToCart: false });
        var pos = this.state.productsArr.findIndex((el) => {
            if (el.productId === cartObj.productId)
                return true;
            else
                return false;
        });
        if (pos >= 0) {
            this.setState((prevState) => {
                prevState.productsArr[pos].quantity -= cartObj.quantitySelected;
                return prevState;
            })
        }
        this.props.onCartObjConfirm(cartObj);
        /* var tempArr = [...this.state.productsArr];
        var pos = tempArr.findIndex((el) => {
            if (el.productId === cartObj.productId)
                return true;
        });
        if (pos >= 0) {
            tempArr[pos].quantity -= cartObj.quantitySelected;
            this.setState({ productsArr: tempArr });
        }
 */


    }
    render()
    {
        var productsArr = this.state.productsArr;
        // dynamic generation of cards based on the number of elements in the productsArr
        var cardArr = productsArr.map(item => {
            return (
                <div key ={item.productId} className="card bg-warning m-2" style={{ width: "18rem" }}>
                    <img className="card-img-top" alt={item.productName} src={item.imageUrl} style={{ width: "100px", height: "100px", margin: "auto" }} />
                    <div className="card-body">
                        <p className="card-title" >{item.productName}</p>
                        <p className="card-text">Quantity : {item.quantity}</p>
                        <p className="card-text">Price : {item.price}</p>
                        <input type="button" value="Add Cart"
                            className="btn btn-primary" style={{ width: "100px" }}
                            onClick={this.addCartEventHandler.bind(this, item)} />

                    </div>
                </div>
            )
        })

        return(
            <React.Fragment>
            <div className="card-group">
                            {cardArr}
                        </div>
                        {this.state.showAddToCart && <AddToCart onConfirmSelection={this.onConfirmSelectionEventHandler} onCancelConfirm={this.onCancelConfirmEventHandler} productDetails={this.state.selectedProduct}></AddToCart>}
            </React.Fragment>
        );
    }
}
export default Products;