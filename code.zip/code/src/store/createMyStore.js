import {createStore,combineReducers,applyMiddleware} from "redux";

import empReducer from "../reducers/empReducer";
import projectsReducer from "../reducers/projectsReducer";
import usersReducers from "../reducers/userReducer";

import thunk from "redux-thunk";
var combinedReducer=combineReducers(
    {
      employees:empReducer,
      projects:projectsReducer,
      users:usersReducers
    }
  );
var store=createStore(combinedReducer,applyMiddleware(thunk));
export default store;
  
