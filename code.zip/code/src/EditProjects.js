import React from 'react'

class EditProjects extends React.Component
{
    backEventHandler=()=>{
        // go back to the projects page
        this.props.history.goBack();
        //this.props.history.go(-1);
        //this.props.history.push("/projects");
        //this.props.history.replace("/projects");
    }
    confirmEventHandler=()=>{
        var des=prompt("Enter the new description");
        var updatedProject={...this.props.history.location.state,projectDescription:des};
        this.props.history.push("/projects",updatedProject);
    }
    render()
    {
        console.log(this.props);
        var projectId=this.props.match.params.pId || "No details found"
        return(
            <React.Fragment>
                <h1>Edit Project Details</h1>
                <h2> Project Id: {projectId}</h2>
                <h2> Project Name : {this.props.history.location.state.projectName}</h2>
                <h2> Project description : {this.props.history.location.state.projectDescription}</h2>
                <br/>
                <input type="button" value="Back" 
                className="btn btn-primary m-2" onClick={this.backEventHandler} />
                <input type="button" value="Confirm" 
                className="btn btn-primary m-2" onClick={this.confirmEventHandler} />
                
            </React.Fragment>
        );
    }
}

export default EditProjects;