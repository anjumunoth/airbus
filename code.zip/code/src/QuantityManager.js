import React from 'react'

class QuantityManager extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            qty:1,
            maxQuantity:(this.props.maxQuantity|| 10),
            productId:this.props.productId};
    }
    static getDerivedStateFromProps(newProps,prevState)
    {
        if(newProps.productId !== prevState.productId)
        {
            return {...prevState,qty:1,maxQuantity:newProps.maxQuantity,productId:newProps.productId}
        }
        else
        {
            return prevState;
        }
    }
    decrement = () => {
        this.setState((prevState)=>{
            if(prevState.qty > 1)
                return {qty:prevState.qty-1}
            else {
                return prevState;
            }
        },()=>{
            this.props.onQuantityChanged(this.state.qty);
        });
        
    }

    increment = () => {
        this.setState((prevState)=>{
            if(prevState.qty<this.state.maxQuantity)
                return {qty:prevState.qty + 1}
            else {
                return prevState;
            }
        },()=>{
            this.props.onQuantityChanged(this.state.qty);
        });
        
    }
    render()
    {
        
        return (
            <div>
        <button onClick={this.decrement} disabled={(this.state.qty <=1)}>-</button>
        <span>{this.state.qty}</span>
        <button onClick={this.increment} disabled={this.state.qty >=this.state.maxQuantity}>+</button>
            </div>
        );
    }
}

export default QuantityManager;