// create a component Header
// 2 types of component -- functional component, class component
import React from "react";

class Header extends React.Component {
    render() {
        return (
            <div className="bg-primary container-fluid">
                <div className="row align-items-center">
                    <img className="col-4 img-responsive" src="images/logo.jpg" alt="Logo" />
                    <h2 className="col-8 m-auto text-warning" >My Shopping Cart</h2>
                  
                </div>

            </div>
        );
    }
}

export default Header;