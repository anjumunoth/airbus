import React, { Component } from 'react'
import Child from "./Child";
import {connect} from "react-redux";

function mapDerivedStateToProps(state)
{
    var pos=state.employees.employees.findIndex(item=>item.empId === 101);

    return {
        employee:state.employees.employees[pos]
    }
}
class Parent extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            showChild:false,
            employee:this.props.employee
        };
    }
    editEmployeeDetailsEventHandler=()=>{
        this.setState({showChild:true});
    }
    confirmSaveEventHandler=()=>{
       // alert("Data received from the Child");
        this.setState({showChild:false});
       
    }
    render() {
        var emp = this.state.employee;
        return (
            <React.Fragment>
                <h1>Employee Details </h1>
                <table className="table table-bordered table-sm bg-primary text-warning">
                    <tbody>
                        <tr>
                            <td>Employee Id</td>
                            <td>{emp.empId}</td>
                        </tr>
                        <tr>
                            <td>Employee Name</td>
                            <td>{emp.empName}</td>
                        </tr>
                        <tr>
                            <td>Salary</td>
                            <td>{emp.salary}</td>
                        </tr>
                        <tr>
                            <td colSpan="2">
                                <input type="button" className="bg-warning text-primary" value="Edit Employee Details" onClick={this.editEmployeeDetailsEventHandler} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                {this.state.showChild && <Child age ={"12"} editableEmployee={emp} onConfirmSave={this.confirmSaveEventHandler}></Child>}
            </React.Fragment>
        );
    }
}

export default connect(mapDerivedStateToProps)(Parent);