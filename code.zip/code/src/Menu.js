import React from 'react'
import { Link } from 'react-router-dom';
import "./Menu.css";

var Menu = () => {
    return (
        <React.Fragment>
            <ul id="mainMenu">
                <li>
                    <Link to="/emp">Employees</Link>
                </li>
                <li>
                    <Link to="/products">Products</Link>
                </li>
                <li>
                    <Link to="/employee">Employee Details</Link>
                </li>
                <li>
                    <Link to="/home">Home</Link>
                </li>
                <li>
                    <Link to="/timer">Timer</Link>
                </li>
                <li>
                    <Link to="/sample">Sample</Link>
                </li>
                <li>
                    <Link to="/login">Login</Link>
                </li>
                <li>
                    <Link to="/projects">Projects</Link>
                </li>
                <li>
                    <Link to="/courses">Courses</Link>
                </li>
                <li>
                    <Link to="/users">Users</Link>
                </li>
            </ul>
        </React.Fragment>
    );
}
export default Menu;