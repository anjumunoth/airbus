function ComponentB()
{
    return(
        <div>
            <h1> Component B </h1>
        </div>
    )
}

export default ComponentB