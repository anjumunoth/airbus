import axios from "axios";
export function addEmpActionCreator(p1)
{
  return {type:"ADD_EMP",payload:p1};
}

export function delEmpActionCreator(p1)
{
  return {type:"DEL_EMP",payload:p1};
}

export function updateEmpActionCreator(p1)
{
  return {type:"UPDATE_EMP",payload:p1};
}


export function fetchDataFromApi(myData)
{
    return (dispatch)=>{
        var serverUrl = "https://jsonplaceholder.typicode.com/photos";
        axios.get(serverUrl)
            .then((response) => {
                
                console.log(response.data);
                var myData=response.data.slice(0,10);
                console.log("response",myData);
                return dispatch({type:"ADD_USERS",payload:myData});
        
            })
            .catch((err) => {
                //console.log(err)
            })
        
               
    }
}

