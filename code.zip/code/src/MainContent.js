import React from "react";
import AddToCart from "./AddToCart";
import Cart from "./Cart";
import Products from "./Products";

class MainContent extends React.Component {
    constructor() {
        super();
        this.state = { 
            showCart: false,
            cartArr:[],
            productsArr:[
                { productId: 101, productName: "Iphone 13 pro max", description: "Apple Iphone 13 pro max. Flagship model of Iphone", quantity: 10, price: 125000, imageUrl: "images/iphone.jpg" },
                { productId: 102, productName: "Samsung note 20", description: "Samsung note 20 Flagship model of Samsung", quantity: 5, price: 75000, imageUrl: "images/samsung.jpg" },
                { productId: 103, productName: "Google pixel 4a", description: "Google pixel 4a Flagship model of Google", quantity: 12, price: 85000, imageUrl: "images/pixel.jpg" },
                { productId: 104, productName: "Vivo v17", description: "Vivo v17 Flagship model of Vivo", quantity: 4, price: 15000, imageUrl: "images/vivo.jpg" },
                { productId: 105, productName: "Huawei ", description: "Huawei note 20 Flagship model of Huawei", quantity: 15, price: 35000, imageUrl: "images/huawei.jpg" }

            ]
         };
    }
    cartObjConfirmEventHandler=(cartObj)=>{
        console.log("Cart Obj in Main Content ",cartObj);
        this.setState((prevState)=>{
            var pos=prevState.cartArr.findIndex(item=>item.productId === cartObj.productId);
            if(pos < 0)
            {
                prevState.cartArr.push(cartObj);
            }
            else
            {
                prevState.cartArr[pos].quantitySelected+=cartObj.quantitySelected;
            }
            return prevState;
        })

    }
    render() {

        return (
            <div>
                {!this.state.showCart && (
                    <div>
                        <div className="container m-1">
                            <div className="row">
                                <h1 className="col-5"> Product Details</h1>
                                <div className="col-3 offset-4">
                                    <input className="btn btn-primary" type="button" value="Cart"
                                        onClick={() => { this.setState({ showCart: true }) }} />
                                </div>
                            </div>
                            <div>
                                <Products productsArr={this.state.productsArr} onCartObjConfirm={this.cartObjConfirmEventHandler}></Products>
                            </div>
                        </div>

                    </div>)
                }

                <div>
                    {this.state.showCart &&
                        (
                            <div>
                                <div className="container">
                                    <div className="row">
                                        <div className="col-3 offset-9">
                                            <input className="btn btn-primary" type="button" value="Products" onClick={() => {
                                                this.setState({ showCart: false });
                                            }} />
                                        </div>

                                    </div>
                                    <Cart cartArr={this.state.cartArr}></Cart>
                                </div>
                            </div>
                        )}
                </div>
            </div>
        );
    }
}

export default MainContent;