import React,{useEffect,useState} from 'react'

function Child2(props)
{
    var [userName,setUserName]=useState(props.userName);
    var [password,setPassword]=useState(props.password);
    var [err,setErr]=useState();
    useEffect(()=>{
        //getDerivedStateFromProps
        setUserName(props.userName);
        if(userName === "")
        {
            setErr("Username is required");
        }
        else
        {
            setErr("")
        }
        return(()=>{
            // whenever the component gets unmounted
            // emit an event;
            console.log("Component is going to be unmounted ");
            alert("Alert1 for componentWillUnMount")
            props.onUnMount();
        })
    },[props.userName])
    useEffect(()=>{
        return(()=>{
            alert("Alert2 for componentWillUnMount")
            alert("Child 2 is going to be unmounted");
        })
    },[]);
    var closeEventHandler=()=>{
        props.closeChild2();
    }
    return (
        <React.Fragment>
            <h1> Child 2 component loaded</h1>
            <h2>{err}</h2>
            <input type="button" value="Close" onClick={closeEventHandler}/>
        </React.Fragment>
    )
}
export default Child2;