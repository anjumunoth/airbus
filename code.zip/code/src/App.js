import logo from './logo.svg';
import './App.css';
import Header from "./Header";
import Footer from "./Footer";
import MainContent from "./MainContent";
import Sample from './Sample';
import QuantityManager from './QuantityManager';
import Parent from './Parent';
import CustomTimer from './CustomTimer';
import Login from "./Login";
import React from 'react';
import Menu from "./Menu";
import Display from './Display';

// functional component -- return the virtual DOM
function App() {
  var textColor={color:"blue"};
  /* return (
    <div>
      <Login></Login>
      <h1 id="headerH1" style= {textColor}>Welcome to the react training</h1>
      <img style={{border:"5px solid green"}} src="images/flower.jpg" alt="Image of a flower"/>
      <img src={flowers} alt="Image of a flower"/>
      <div style={{backgroundColor:"cyan","color":"blue"}}>
      <a href="https://www.airbus.com/">Go to airbus</a>
      <p> Airbus is an international reference in the aerospace sector. We design, manufacture and deliver industry-leading commercial aircraft, helicopters, military transports, satellites and launch vehicles, as well as providing data services, navigation, secure communications, urban mobility and other solutions for customers on a global scale</p>
      </div>
      <Parent></Parent>
      <Sample></Sample>
      <QuantityManager></QuantityManager>
      <Header></Header>
      <MainContent></MainContent>
      <Footer></Footer>
    </div>
  ); */
  return(
    <React.Fragment>
      <Header>      
      </Header>
      <Menu></Menu>
      <Display></Display>
      <Footer></Footer>
    </React.Fragment>
  )
}

export default App;
/*
Pass data between 2 components:
1. Pass from parent to child -- using props
2. Pass fro child to parent -- using events and event emitters
3. pass data from 1 sibling to another -- lift the state up to the common parent and send it to the sibling using props
4. pass data via routing --using parameters
5. pass data via routing -- using state(routing)
6. pass data using Redux
7. pass data using Context

*/