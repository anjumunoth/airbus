import React from 'react'
import { act } from 'react-dom/test-utils';
import { Link,Route,Switch,Redirect,Prompt } from 'react-router-dom';
import { useState } from 'react/cjs/react.development';

var Courses =(props)=>{
    var [allowPrompt,setAllowPrompt]=useState(false)
    console.log(props);
    var angularUrl=props.match.path + "/" + "angular";
    var reactUrl=`${props.match.path}/react`;
    var vueUrl=`${props.match.path}/vue`;
    console.log(props);
    return (
        <React.Fragment>
            <h1> Courses Component</h1>
            <ul id="mainMenu">
                <li>
                    <Link to={angularUrl}>Angular</Link>
                </li>
                <li>
                    <Link to={reactUrl}>React</Link>
                </li>
                <li>
                    <Link to={vueUrl}>Vue</Link>
                </li>
                
            </ul>

            <Switch>
                
                <Route path={angularUrl} render={()=>{
                   return( <h1>Angular contents</h1>)
                }}>
                </Route>
                <Route path={reactUrl} render={()=>{
                    return(<h1>React contents</h1>)
                }}>
                </Route>
                <Route path={vueUrl} render={()=>{
                    return(<h1>Vue contents</h1>)
                }}>
                </Route>
                <Route path ="/courses/" >
                    <Redirect to={angularUrl}></Redirect>
                </Route>
            </Switch>
            <input type="button" value="Toggle" 
            onClick={()=>{
                setAllowPrompt((prevState)=>{ return !prevState});
            }} />
            <p> AllowPrompt:{allowPrompt?"true" :"false"} </p>
            {/* <Prompt when={allowPrompt} message="Are u sure u want to leave the page"></Prompt> */}

            <Prompt message={(location,action)=>{
                if(action === "POP")
                {
                    console.log("POP")
                }
                if(location.pathname.startsWith("/projects"))
                {
                    return true;    
                }
                else
                {
                    return "Are u sure u want to navigate to "+location.pathname; 
                }
            }}></Prompt>
        </React.Fragment>
    );
}
export default Courses;
//courses/Angular
//courses/React