import React,{useState} from 'react'
import {connect} from "react-redux";
import {addEmpActionCreator,delEmpActionCreator,updateEmpActionCreator} from "./actions/actionCreator";

function mapDerivedStateToProps(state)
{
    // whatever is returned from this function will be added to the props
    //state:{employees:[],projects:[],errMsg:""}
    console.log(state);
    return ({"empArr":state.employees.employees,"errMsg":state.employees.errMsg});
} 

function mapDispatchToProps(dispatch)
{
    // whatever is returned from this function will be added to the props
    return ({
        onEdit:(editedObj)=>{return dispatch(updateEmpActionCreator(editedObj))},
        onDeleteConfirmation:(deleteObj)=>{ return dispatch(delEmpActionCreator(deleteObj))}
    })

}

class Employees extends React.Component
{
    deleteEmpEventHandler=(deleteEmp)=>{
        // dispatch an action -- functionality of redux
        var deleteObj={empId:deleteEmp.empId}
        // dispatch(delEmpActionCreator(deleteObj));
        this.props.onDeleteConfirmation(deleteObj);
        this.setState({});
    }
    editEmpEventHandler=(editEmp)=>{
        var empName=prompt("Enter the new employee Name for empId :"+editEmp.empId)
        var salary=prompt("Enter the new salary for empId :"+editEmp.empId);
        var editedEmp={empId:editEmp.empId,empName,salary};
        this.props.onEdit(editedEmp);
        this.setState({});
    }
    render()
    {
        console.log(this.props);//
        var trArr=this.props.empArr.map((item)=>{
            return(
            <tr key={item.empId}>
                <td>
                    {item.empId}
                </td>
                <td>
                    {item.empName}
                </td>
                <td>
                    {item.salary}
                </td>
                <td>
                    <input type="button" value="Edit" className="btn btn-success m-2" onClick={this.editEmpEventHandler.bind(this,item)} />
                    <input type="button" value="Delete" className="btn btn-danger m-2" onClick={this.deleteEmpEventHandler.bind(this,item)} />
                </td>
            </tr>
            )
        })
        return(
            <React.Fragment>
                <h1>Employee Management </h1>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Employee Id</th>
                            <th>Employee Name</th>
                            <th>Salary</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {trArr}
                    </tbody>
                </table>
            </React.Fragment>
        )
    }
}

export default connect(mapDerivedStateToProps,mapDispatchToProps)(Employees);