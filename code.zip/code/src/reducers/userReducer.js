function usersReducers(state={users:[]},action)
{
    console.log("Inside usersReducers")
    console.log(action);
    var newState={...state};
    if(action.type == "ADD_USERS")
    {
        console.log("In the users reducer",action.payload);
        newState.users=[...action.payload];
    }
    return newState;
}

export default usersReducers;