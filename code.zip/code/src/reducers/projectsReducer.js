var projects=[{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];

function projectsReducer(state={projects:projects},action)
{
  var newState={...state};
  switch(action.type)
  {
    case "CLEAR_DATA":
        newState.projects.splice(0,(newState.projects.length));
      break;
    case "ADD_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos <0)
      {
        newState.projects.push(action.payload);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="projectId already exists";
      }
     
      break;
    case "UPDATE_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos >=0)
      {
        newState.projects[pos]=action.payload;
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId not found";
      }
      break;
    case "DELETE_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos >=0)
      {
        newState.projects.splice(pos,1);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId doesnot exists";
      }
      break;
  }
  return newState;
}

export default projectsReducer;