import React from 'react'
import QuantityManager from './QuantityManager';

class AddToCart extends React.Component {
    constructor(props) {
        super(props);
        //props are immutable data;
        // this.props.productDetails.quantity=100;// wrong practice
        this.state={productDetails:this.props.productDetails,quantitySelected:1};
        console.log(this.props);
    }
    componentWillUnmount()
    {
        alert("The selection is going to be lost. Pls click OK to proceed");
    }
    static getDerivedStateFromProps(newProps,prevState)
    {
        console.log("getDerivedStateFromProps called");
        if(newProps.productDetails.productId !== prevState.productDetails.productId)
        {
            alert("Product changed");
            return {...prevState,productDetails:newProps.productDetails,quantitySelected:1};
        }
        else
        {
            return prevState;
        }

    }
    confirmEventHandler=()=>{
        var cartObj={...this.props.productDetails,quantitySelected:this.state.quantitySelected};
        console.log(cartObj);
        this.props.onConfirmSelection(cartObj);
    }
    quantityChangedEventHandler=(quantitySelected)=>{
        this.setState({quantitySelected:quantitySelected});
    }
    cancelEventHandler=()=>{
        this.props.onCancelConfirm();
    }
    render() {
        console.log(this.state.productDetails);
        var item = { ...this.state.productDetails };
        return (
            <React.Fragment>
                <h1>Add To Cart Component</h1>
                <div className="container">
                    <div className="row">
                        <div className="col-4 offset-4">
                            <div className="card bg-warning m-5" style={{ width: "18rem" }}>
                                <img className="card-img-top" alt={item.productName} src={item.imageUrl} style={{ width: "100px", height: "100px", margin: "auto" }} />
                                <div className="card-body">
                                    <p className="card-title" >{item.productName}</p>
                                    <p className="card-text">Quantity : {item.quantity}</p>
                                    <p className="card-text">Price : {item.price}</p>
                                    <div>
                                        <QuantityManager productId={item.productId} maxQuantity={item.quantity} onQuantityChanged={this.quantityChangedEventHandler}></QuantityManager>
                                    </div>
                                    <div>
                                        <input type="button" value="Confirm" className="btn btn-success" onClick={this.confirmEventHandler} />
                                        <input type="button" value="Cancel" className="btn btn-success" onClick={this.cancelEventHandler} />

                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}

export default AddToCart