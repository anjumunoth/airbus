import React from 'react'

class Cart extends React.Component
{
    render()
    {
        console.log(this.props.cartArr);
        // display cartArr in a table format
        return (
            <h1> Cart Component</h1>
        )
    }
}

export default Cart;