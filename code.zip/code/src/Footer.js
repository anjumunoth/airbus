import React from 'react'

function Footer(props)
{
    return(
        <div className="bg-primary text-warning">
            <h3>Copyright Anju Munoth@2021</h3>
        </div>
    )
}

export default Footer;