import React from "react";
import { Route, Switch,Redirect } from "react-router-dom";
import CustomTimer from "./CustomTimer";
import MainContent from "./MainContent";
import Sample from "./Sample";
import Parent from "./Parent";
import Login from "./Login";
import flowers from "./flowers2.jpg";
import Projects from "./Projects";
import EditProjects from "./EditProjects";
import Courses from "./Courses";
import Users from "./Users";
import UsersPicture from "./UsersPicture";
import Employees from "./Employees";
import UsersFromRedux from "./UsersFromRedux";

var Display = () => {
    return (
        <React.Fragment>
            <Switch>
                <Route path="/" exact >
                    <Redirect to="/products"></Redirect>
                </Route>
                <Route path="/usersFromRedux" component={UsersFromRedux}></Route>
                <Route path="/users/picture/:id" component={UsersPicture}></Route>
                <Route path="/users" component={Users}></Route>
                <Route path="/emp" component={Employees}></Route>
                <Route path="/courses" component={Courses}></Route>
                <Route path="/projects/edit/:pId" component={EditProjects}></Route>
                <Route path="/projects/edit" component={EditProjects}></Route>
                <Route path="/projects" component={Projects} />
                <Route path="/products" component={MainContent}></Route>
                <Route path="/login" component={Login}></Route>
                <Route path="/employee" component={Parent}></Route>
                <Route path="/timer" component={CustomTimer}></Route>
                <Route path="/sample" component={Sample}></Route>
                <Route path="/home" render={() => {
                    var textColor = { color: "blue" };
                    return (
                        <React.Fragment>

                            <h1 id="headerH1" style={textColor}>Welcome to the react training</h1>
                            <img style={{ border: "5px solid green" }} src="images/flower.jpg" alt="Image of a flower" />
                            <img src={flowers} alt="Image of a flower" />
                            <div style={{ backgroundColor: "cyan", "color": "blue" }}>
                                <a href="https://www.airbus.com/">Go to airbus</a>
                                <p> Airbus is an international reference in the aerospace sector. We design, manufacture and deliver industry-leading commercial aircraft, helicopters, military transports, satellites and launch vehicles, as well as providing data services, navigation, secure communications, urban mobility and other solutions for customers on a global scale</p>
                            </div>
                        </React.Fragment>
                    )
                }}></Route>
                <Route path="**" render={() => {
                    return (<h1>Page not found</h1>)
                }}></Route>

            </Switch>
        </React.Fragment>
    )
}

export default Display;