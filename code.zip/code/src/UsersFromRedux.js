import React from 'react'
import {fetchDataFromApi} from "./actions/actionCreator";
import {connect} from "react-redux";
import axios from "axios";

import {Link} from "react-router-dom"
function mapDerivedStateToProps(state)
{
    console.log("State in users component",state);
    return (
        {
            albumArr:state.users.users
        }
    )
}
function mapDispatchToProps(dispatch)
{
    return (
        {
            onGetData:(myData)=>{return dispatch(fetchDataFromApi(myData))}
        }
    )
}
class UsersFromRedux extends React.Component {
    constructor(props)
    {
        super(props);
        this.state={users:this.props.albumArr}
    }
    componentDidMount()
    {
        this.props.onGetData();
        //dispatch an action
           
        

    }
    render() {
        console.log(this.props);
        var linkArr = this.props.albumArr.map((item) => {
            return (
                <li>
                    <Link to={{
                        pathname: `/users/picture/${item.id}`,
                        state: { item }
                    }}>{item.id}</Link>
                </li>
            )
        })
        return (
            <React.Fragment>
                <h1>Users Component</h1>
                <ul id="mainMenu">
                    {linkArr}
                </ul>
            </React.Fragment>
        );
    }
}

export default connect(mapDerivedStateToProps,mapDispatchToProps)(UsersFromRedux);