import React,{useState,useEffect} from "react";
import {Link} from "react-router-dom";

var Projects = (props) => {
    var editDetailsEventHandler=(selectedProject)=>{
        console.log("Selected Project",selectedProject);
        // navigate to /projects/edit
        // send a param as well
        // send the object as well
        var url="/projects/edit/"+selectedProject.projectId;
        props.history.push(url,selectedProject);
    }
    var [projectArr,setProjectArr]=useState([{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
    {projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
    {projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
    {projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
    {projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}]);

    useEffect(()=>{
        if(props.history.location.state)
        {
            setProjectArr((prevState)=>{
                var pos=prevState.findIndex(item=>item.projectId === props.history.location.state.projectId)
                if(pos >=0)
                {
                    prevState[pos]=props.history.location.state;
                }
                return [...prevState];
            })
        }
    },[props.history.location.state])
    var trarr = projectArr.map((item)=>{
        return (
        <tr key={item.projectId}>
            <td>
                {item.projectId}
            </td>
            <td>
                {item.projectName}
            </td>
            <td>
                {item.projectDescription}
            </td>
            <td>
                <Link to ={`/projects/edit/${item.projectId}`}> Edit </Link>
                <input type="button" value="Edit Details" className="btn btn-primary"
                onClick={()=>{  editDetailsEventHandler(item); }}/>
            </td>
        </tr>
        )
    } );
    
    return (
        <div>
            <h1>Projects</h1>
            <table className="table table-bordered table-primary">
                <thead>
                    <tr>
                        <th>
                            Projects Id:
                        </th>
                        <th>
                            Project name
                        </th>
                        <th>
                            Description
                        </th>
                        <th>
                            Actions
                        </th>
                    </tr>

                </thead>
                <tbody>
                    {trarr}
                </tbody>
            </table>
        </div>
    )
}

export default Projects;