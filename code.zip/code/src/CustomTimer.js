import React from 'react'

class CustomTimer extends React.Component
{
    constructor()
    {
        super();
        this.state={
        currentDate:new Date(),
        clearIntervalId:0
    };
    }
    componentDidMount()
    {
        var clearIntervalId=setInterval(()=>{
            this.setState({currentDate:new Date()},()=>{
                console.log(this.state.currentDate);
            })
        },1000)
        this.setState({clearIntervalId:clearIntervalId});

    }

    componentWillUnmount()
    {
        clearInterval(this.state.clearIntervalId);
    }
    


    render()
    {
        return(
            <React.Fragment>
                <div>
                    Time:{this.state.currentDate.toString()} 
                </div>
            </React.Fragment>
        );

    }
}
export default CustomTimer;