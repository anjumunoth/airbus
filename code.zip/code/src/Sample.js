import React from 'react'
import ComponentA from './ComponentA';
import ComponentB from './ComponentB';
class Sample extends React.Component
{
    constructor()
    {
        super();
        this.state={ctr:0,customValue:0,showComponentA:false,showComponentB:false};
        this.decCounterEventHandler=this.decCounterEventHandler.bind(this);// binding the scope of component to the event handler
        this.decValueRef=React.createRef();
        this.num1Ref=React.createRef();
        this.num2Ref=React.createRef();

    }
    incCounterEventHandler=(value)=>{
        //this --> component
        console.log("Inc button clicked");
        //this.state.ctr +=1;
        //console.log(this.state);
        // return a new virtual DOM with the changes
        // call the render method again explicitly -- not possible
        // call the render method implicitly -- setState
        this.setState((prevState)=>{return {ctr:prevState.ctr+value}},()=>{
            console.log("Ctr :"+this.state.ctr);
        });//
        //console.log("Ctr :"+this.state.ctr);//0
        // java
        // Employee emp= new Employee();// calling the constructor implicitly

        //Employee(101,"asha");// cannot call the constructor explicitly
        // constructor -- special member function -- initialise the component members-- lifecycle method during the component creation -- first method --cannot be called explicitly -- called only once
        //render -- special member function -- gets implicitly called -- when the component gets mounted -- cannot be called explicitly
    }
    render()
    {
        //conditional rendering
        
        return (
            <div>
                <p> Ctr : {this.state.ctr}</p>
                <input type="button" value="Increment counter" onClick={this.incCounterEventHandler.bind(this,1)}/>
                <input type="button" value="Decrement counter" onClick={this.decCounterEventHandler.bind(this,1)}/>
                <input type="button" value="Increment the counter by 5" onClick={this.incCounterEventHandler.bind(this,5)}/>
                <br/>
                <input type="button" value="Decrement the counter by 3" onClick={this.decCounterEventHandler.bind(this,3)}/>
                <input type="button" value="Decrement And Increment" onClick={this.incDecCounterEventHandler.bind(this,10,20)}/>
                <br />
                Enter the value to increment with <input type="text" onChange={this.changetxtValueEventHandler} />
                <input type="button" value="Custom increment" onClick={this.incCustomCounterEventHandler}/>
                Enter the value to decrement with <input type="text" ref={this.decValueRef} />
                <input type="button" value="Custom decrement" onClick={this.decCustomCounterEventHandler}/>
                <br />
                <input type="text" placeholder="Enter number1" ref={this.num1Ref}/>
                <input type="text" placeholder="Enter number2" ref={this.num2Ref} />
                <input type="button" value="Show Results" onClick={this.showResutsEventHandler}/>
                <br/>Using Logical And:
                {this.state.showComponentA  && <ComponentA></ComponentA> }
                {this.state.showComponentB  && <ComponentB></ComponentB> }
                Using Ternary operator:{this.state.showComponentA === true ? <ComponentA></ComponentA>: <ComponentB></ComponentB>}
            </div>
        );
    }
    decCounterEventHandler(value)
    {
        // this -- object on which the method is called
        // error -- this is undefined
        alert("Dec button clicked");
        this.setState((prevState)=>{return {ctr:prevState.ctr-value}},()=>{
            console.log("Ctr :"+this.state.ctr);
        });
    }
    incDecCounterEventHandler(decValue,incValue)
    {
        this.setState((prevState)=>({ctr:prevState.ctr-decValue}));
        this.setState((prevState)=>{return {ctr:prevState.ctr+incValue}},()=>{
            console.log("Ctr :"+this.state.ctr);
        });
    }
    changetxtValueEventHandler=(event)=>{
        console.log("On change event called");
        this.setState({customValue:parseInt(event.target.value)});// merge the contents
        
    }
    incCustomCounterEventHandler=()=>{

        this.setState((prevState)=>{return {ctr:prevState.ctr+prevState.customValue}},()=>{
            console.log("Ctr :"+this.state.ctr);
        });
    }
    decCustomCounterEventHandler=()=>{
        console.log("decValueRef",this.decValueRef);
        this.setState((prevState)=>{return {ctr:prevState.ctr-parseInt(this.decValueRef.current.value)}},()=>{
            console.log("Ctr :"+this.state.ctr);
        });
    }
    showResutsEventHandler=()=>{
        var num1=parseInt(this.num1Ref.current.value);
        var num2=parseInt(this.num2Ref.current.value);
        if(num1>num2)
        {
           this.setState({showComponentA:true,showComponentB:false})
        }
        else
        {
            this.setState({showComponentB:true,showComponentA:false})
        }

    }
}

export default Sample;