import React from "react";

var UsersPicture=(props)=>{
    var userDetails=props.history.location.state.item;
    console.log(props.history.location.state.item)
    return(
        <React.Fragment>
            {userDetails.id >=0?
             (<div>
             <h1>Id :{ userDetails.id}</h1>
             <h1>Thumbnail Url :{userDetails.thumbnailUrl}</h1>
             <img src={userDetails.thumbnailUrl}/>
             <h1> Title :{userDetails.title}</h1>
             </div>)
            : "No Details found"}
           
        </React.Fragment>
    )
}
export default UsersPicture;