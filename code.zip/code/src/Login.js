import React,{useEffect,useState,useRef} from "react";
import Child2 from "./Child2"
function Login()
{
    var [userName,setUserName]=useState("");// destructuring
    var [password,setPassword]=useState("");
    var [country,setCountry]=useState("US");
    var [studies,setStudies]=useState();
    var [loading,setLoading]=useState(true);
    var [closeChild2,setCloseChild2]=useState(true);
    var passwordRef=useRef(null);
    var studiesRef=useRef(null);
    
    var [emp,setEmp]=useState({empId:102,empName:"sara"});
    var changeCountrySelection=(event)=>{
        setCountry(event.target.value);
    }
    useEffect(()=>{
        console.log("Effect1 called with no second param");
        
    })
    useEffect(()=>{
        alert("Effect2 called with empty array as second param");
        
    },[])

    useEffect(()=>{
        console.log("Effect3 called with single element in dependency list as second param");
    },[userName]);

    useEffect(()=>{
        console.log("Effect4 called with 2 elements in dependency list as second param");
    },[userName,country]);

    useEffect(()=>{
        //do the api calls
        setInterval(()=>{
            setEmp({empId:101,empName:"asha"});
            setLoading(false);
        },20000)
       
    },[loading])

    var loginEventHandler=()=>{
        alert("Button clicked");
        setPassword(passwordRef.current.value);//async function
        console.log("username",userName);
        console.log("Password",passwordRef.current.value);
        console.log("Password",password);//not the best practice 
        console.log("Studies selected",studiesRef.current.value);
        setStudies(studiesRef.current.value);
    }
    var changeUsernameEventHandler=(event)=>{
        //this.setState({userName:event.target.value});
        setUserName(event.target.value);
        //userName=event.target.value;//will not re render 
        //console.log(userName);//will have the new value;

        
    }
    var onUnMountEventHandler=()=>{
        passwordRef.current.value="";
        setUserName("");
    }
    var closeChild2EventHandler=()=>{
        setCloseChild2(false);
    }
   return (
       <React.Fragment>
           {loading && <h1>Loading .....</h1>}
           <form>
               <input type="text" placeholder="Enter the username" onChange={changeUsernameEventHandler} />
               <input type="password" placeholder="Enter the password" ref={passwordRef} />
               Country :<select value={country} onChange={changeCountrySelection}>
                   <option value="India">India</option>
                   <option value="US" selected>US</option>
                   <option value="Australia">Australia</option>
                   <option value="Europe">Europe</option>
                   </select>
                Studies:<select ref={studiesRef}>
                    <option value="Graduate">Graduate</option>
                    <option value="PostGraduate" selected>PostGraduate</option>
                    <option value="Diploma">Diploma</option>
                    <option value="Others">Others</option>
                    </select>
               <input type="button" value="Login" onClick={loginEventHandler} />
           </form>
           <p> User name :{userName}</p>
           <p>Country:{country}</p>
           <p> Employee Id:{emp.empId}</p>
           {closeChild2 &&<Child2 userName={userName} onUnMount={onUnMountEventHandler} closeChild2={closeChild2EventHandler}></Child2>}
       </React.Fragment>
   )

}
export default Login;
/*
this.passwordRef=React.createRef();//constructor
<input type="text" ref={this.passwordRef} />
Access the value : this.passwordRef.current.value
*/

/*
useEffect --> fat arrow function
useEffect(()=>{},[])
second param -- optional
Based on the dependency list, the effect can be called multiple times

1. Dependency list is not there
 Executed each time render is executed

 2. Dependency list is an empty array
Behaves like a constructor,
Will be executed only once
Before the dom gets created

3. Depenedency list is having an array with a single element
componentDidUpdate()
when userName changed 

4. Dependency list  is having an array with 2 elements


componentDidMount
-- executed only once
-- after the component is mounted
-- api Calls
-- third party subscriptions


componentWillUnmount
-- wrap up operations

*/