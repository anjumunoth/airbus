import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import "bootstrap/dist/css/bootstrap.min.css";
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom';

import { Provider } from "react-redux";
import store from "./store/createMyStore";

// mounting the App Component
ReactDOM.render(
  <Provider store={store}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </Provider>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
//localhost:3000/#/products -- HashRouter


/* import {createStore,combineReducers} from "redux";
var employees=[{
  "empId": 101,
  "empName": "asha",
  "salary": 1001,
  "deptId": "D1"
}, {
  "empId": 102,
  "empName": "Gaurav",
  "salary": 2000,
  "deptId": "D1"
}, {
  "empId": 103,
  "empName": "Karan",
  "salary": 2000,
  "deptId": "D2"
},
{
  "empId": 104,
  "empName": "Kishan",
  "salary": 3000,
  "deptId": "D1"
},
{
  "empId": 105,
  "empName": "Keshav",
  "salary": 3500,
  "deptId": "D2"
},
{
  "empId": 106,
  "empName": "Pran",
  "salary": 4000,
  "deptId":null,
  "hobbies":["singing","dancing","cooking"],
  "isMarried":false
},
{
  "empId": 107,
  "empName": "Saurav",
  "salary": 3800
}
]
// create actions
var addEmployee={type:"ADD_EMP",payload:{"empId": 108,"empName": "Pinky","salary": 45678}}

var deleteEmployee={type:"DEL_EMP",payload:{empId:105}}

var updateEmployee={type:"UPDATE_EMP",payload:{"empId": 107,"empName": "Farooq","salary": 1800}}

// create reducer

function empReducer(state={employees:employees,errMsg:""},action)
{
  var newState={...state};
  switch(action.type)
  {
    case "CLEAR_DATA":
        newState.employees.splice(0,(newState.employees.length));
      break;
    case "ADD_EMP":
      var pos=newState.employees.findIndex((element)=>element.empId===action.payload.empId)
      if(pos <0)
      {
        newState.employees.push(action.payload);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId already exists";
      }

      break;
    case "DEL_EMP":
      var pos=newState.employees.findIndex((element)=>element.empId===action.payload.empId)
      if(pos >=0)
      {
        newState.employees.splice(pos,1);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId doesnot exists";
      }
      break;
    case "UPDATE_EMP":
      var pos=newState.employees.findIndex((element)=>element.empId===action.payload.empId)
      if(pos >=0)
      {
        newState.employees[pos]=action.payload;
        newState.errMsg="";
        console.log(newState);
      }
      else
      {
        newState.errMsg="EmpId not found";
      }
      break;
  }
  return newState;
}
var projects=[{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];

function projectsReducer(state={projects:projects},action)
{
  var newState={...state};
  switch(action.type)
  {
    case "CLEAR_DATA":
        newState.projects.splice(0,(newState.projects.length));
      break;
    case "ADD_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos <0)
      {
        newState.projects.push(action.payload);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="projectId already exists";
      }

      break;
    case "UPDATE_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos >=0)
      {
        newState.projects[pos]=action.payload;
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId not found";
      }
      break;
    case "DELETE_PROJECT":
      var pos=newState.projects.findIndex((element)=>element.projectId===action.payload.projectId)
      if(pos >=0)
      {
        newState.projects.splice(pos,1);
        newState.errMsg="";
      }
      else
      {
        newState.errMsg="EmpId doesnot exists";
      }
      break;
  }
  return newState;
}
//var store=createStore(empReducer,{employees:employees,errMsg:""});
var combinedReducer=combineReducers(
  {
    employees:empReducer,
    projects:projectsReducer
  }
)
var store=createStore(combinedReducer)
store.subscribe(()=>{
  console.log("State",store.getState());
})

store.dispatch(addEmployee);
store.dispatch({type:"ADD_EMP",payload:{empId:109,empName:"sara",salary:4567}});
store.dispatch({type:"ADD_EMP",payload:{empId:101,empName:"sara",salary:4567}});
// actionCreator:
function addEmpActionCreator(p1)
{
  return {type:"ADD_EMP",payload:p1};
}

function delEmpActionCreator(p1)
{
  return {type:"DEL_EMP",payload:p1};
}

function updateEmpActionCreator(p1)
{
  return {type:"UPDATE_EMP",payload:p1};
}
var emp1={empId:110,empName:"tara",salary:876};
store.dispatch(addEmpActionCreator(emp1));

store.dispatch(delEmpActionCreator({empId:103}));

store.dispatch(updateEmpActionCreator({empId:101,empName:"aishwarya",salary:10000}))
store.dispatch({type:"ADD_PROJECT",payload:{projectId:"P106",projectName:"Shopping Cart"}})


store.dispatch({type:"CLEAR_DATA"});
//Both the arrays will be empty
 */