import React from 'react';
import axios from "axios";
import {Link} from "react-router-dom";

class Users extends React.Component {
    constructor(props) {
        super(props);
        this.state = { albumArr: [] };
    }
    componentDidMount() {
        var serverUrl = "https://jsonplaceholder.typicode.com/photos";
        axios.get(serverUrl)
            .then((response) => {
                //console.log(response);
                this.setState({ albumArr: response.data.slice(0, 10) }, () => {
                    console.log(this.state.albumArr);
                });
            })
            .catch((err) => {
                console.log(err)
            })
    }
    render() {
        var linkArr = this.state.albumArr.map((item) => {
            return (
                <li>
                    <Link to={{
                        pathname:`/users/picture/${item.id}`,
                        state:{item}
                    }}>{item.id}</Link>
                </li>
            )
        })
        return (
            <React.Fragment>
                <h1>Users Component</h1>
                <ul id="mainMenu">
                    {linkArr}
                </ul>
            </React.Fragment>
        );
    }
}

export default Users