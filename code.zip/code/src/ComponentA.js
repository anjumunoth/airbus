function ComponentA()
{
    return(
        <div>
            <h1> Component A </h1>
        </div>
    )
}

export default ComponentA